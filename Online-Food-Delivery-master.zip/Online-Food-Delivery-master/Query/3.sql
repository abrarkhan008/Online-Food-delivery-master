delete from cuisine
Where cuisineid=16;
