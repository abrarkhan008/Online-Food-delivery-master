select fname,lname
From customer
Where allergy=’egg’;
