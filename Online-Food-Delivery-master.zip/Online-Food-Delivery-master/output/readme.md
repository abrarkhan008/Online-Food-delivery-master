Result of Imtermediate step.
