Images used in project
